# BLACK RUSSIA: ОНЛАЙН
# DATABASE ARCHITECTURE

## CORE RULE

Источник истины для базы данных — Supabase PostgreSQL.

НЕ придумывай новые таблицы, если задачу можно решить существующими.

НЕ переименовывай таблицы.

НЕ переименовывай поля.

НЕ создавай альтернативную систему пользователей.

---

# AUTHENTICATION / IDENTITY

В проекте НЕТ Supabase Auth.

В проекте НЕТ email/password регистрации.

В проекте НЕТ паролей.

Игрок идентифицируется через Telegram Mini App.

Telegram передаёт:

- telegram_id
- username
- first_name
- last_name
- photo_url
- initData

ВАЖНО:

initDataUnsafe НЕ считается доверенным.

Нельзя использовать initDataUnsafe для критических операций.

Telegram initData должен проверяться на сервере.

---

# PLAYER ID

Главный внутренний идентификатор игрока:

uid

Тип:

BIGINT

UID автоматически создаётся PostgreSQL через IDENTITY.

Пример:

#1
#2
#3
...
#1847

UID никогда не должен переиспользоваться.

UID является постоянным игровым идентификатором.

---

# TELEGRAM ID

telegram_id:

BIGINT

Он является внешним идентификатором Telegram.

telegram_id уникален.

telegram_id НЕ является игровым UID.

Никогда не путать:

telegram_id != uid

---

# PROFILES

Таблица:

profiles

Поля:

uid
telegram_id
telegram_username
first_name
last_name
avatar_url
nickname
level
experience
status
last_seen_at
is_verified
is_banned
is_deleted
created_at
updated_at

---

# PLAYER BALANCES

Таблица:

player_balances

Поля:

uid
cash
bank
updated_at

ВАЖНО:

Frontend никогда не должен самостоятельно менять:

cash
bank

---

# TRANSACTIONS

Таблица:

transactions

Используется для истории денежных операций.

Поля:

id
uid
type
amount
balance_type
description
metadata
created_at

Любое изменение денег должно иметь понятную причину.

---

# JOBS

Таблица:

jobs

Поля:

id
slug
name
required_level
min_reward
max_reward
experience_reward
description
is_active
created_at

Доступность работы определяется required_level.

Работы:

1 уровень:
- Ферма
- Шахта
- Завод

2 уровень:
- Курьер
- Водитель автобуса

3 уровень:
- Угонщик транспортных средств
- Кладоискатель
- Рыбалка
- Водитель мусоровоза

4 уровень:
- Автомеханик
- Охотник

5 уровень:
- Газовщик
- Курьер ПВЗ

7 уровень:
- Складской работник

10 уровень:
- Дальнобойщик

12 уровень:
- Электрик

15 уровень:
- Инкассатор

18 уровень:
- Водолаз

---

# PLAYER JOBS

Таблица:

player_jobs

Поля:

uid
job_id
total_completed
experience
last_completed_at

---

# ITEMS

Таблица:

items

Поля:

id
slug
name
category
description
icon_url
base_price
rarity
is_tradeable
is_active
created_at

rarity:

common
uncommon
rare
epic
legendary

---

# INVENTORY

Таблица:

inventory

Поля:

id
uid
item_id
quantity
metadata
acquired_at

---

# MARKET

Таблицы:

market_listings
market_transactions

Игроки могут:

- выставлять предметы;
- покупать предметы;
- продавать предметы;
- конкурировать по цене.

Критические операции рынка должны выполняться серверной логикой.

Нельзя доверять цене или количеству, переданным клиентом.

---

# BUSINESSES

Таблица:

businesses

Поля:

id
owner_uid
name
type
level
price
income_per_hour
reputation
is_for_sale
created_at
updated_at

---

# VIP

Таблица:

player_vip

Поля:

uid
vip_level
expires_at
updated_at

VIP не должен разрушать игровую экономику.

---

# PROMO CODES

Таблицы:

promo_codes
promo_code_usages

Один игрок не может использовать один промокод дважды.

---

# CHAT

Таблицы:

chat_rooms
chat_members
chat_messages

Типы комнат:

global
private
group

Сообщение содержит:

sender_uid

Нельзя позволять клиенту отправлять сообщение от другого UID.

---

# PLAYER RELATIONSHIPS

Таблица:

player_relationships

Типы:

friend
blocked

---

# EVENTS

Таблицы:

events
event_participants

---

# ACTIVITY FEED

Таблица:

activity_feed

Используется для отображения живых событий проекта.

Примеры:

- игрок продал дорогой предмет;
- игрок вошёл в TOP;
- игрок открыл бизнес;
- совершена крупная покупка;
- произошло изменение цены;
- игрок получил достижение.

---

# NEWS

Таблица:

news

Используется для новостей проекта.

---

# NOTIFICATIONS

Таблица:

notifications

Используется для персональных уведомлений игрока.

---

# DAILY REWARDS

Таблица:

daily_rewards

Один игрок может получить одну ежедневную награду за дату.

---

# PLAYER SETTINGS

Таблица:

player_settings

Настройки:

notifications_enabled
chat_notifications
sound_enabled

---

# PLAYER SESSIONS

Таблица:

player_sessions

Используется для отслеживания активных Mini App сессий после проверки Telegram.

Это НЕ Supabase Auth.

---

# VIEWS

Существуют:

public_players
online_players
richest_players

Не создавать таблицы:

online_players
richest_players

Это VIEW.

---

# SECURITY

Клиентский JavaScript НИКОГДА не должен самостоятельно менять:

cash
bank
experience
level
VIP
inventory quantity
market transaction state
promo code usage
event rewards

Критические операции выполняются через:

Supabase Edge Functions
или
защищённые PostgreSQL RPC

После проверки Telegram initData.

---

# TELEGRAM

Frontend может получить Telegram.WebApp.initData.

Frontend НЕ должен считать:

Telegram.WebApp.initDataUnsafe

доказательством личности.

Проверка Telegram должна происходить на серверной стороне.

---

# FRONTEND

Стек:

HTML
CSS
Vanilla JavaScript

Не использовать React.

Не использовать Vue.

Не использовать Next.js.

Не использовать Tailwind.

Не использовать UI framework.

Не добавлять библиотеки без явного разрешения.

---

# DESIGN

Название:

BLACK RUSSIA: ОНЛАЙН

Основная цветовая гамма:

чёрный
тёмно-серый
красный
светло-серый

Стиль:

premium
dark
mobile-first
urban
compact
modern

Не превращать интерфейс в стандартный dashboard.

---

# NAVIGATION

Главные разделы:

ГЛАВНАЯ
РЫНОК
ЧАТ
ИГРАТЬ
ПРОФИЛЬ

---

# IMPORTANT

Перед изменением базы:

1. Проверь database-schema.md.
2. Проверь существующие таблицы.
3. Используй существующие связи.
4. Не создавай дублирующие таблицы.
5. Не изменяй схему без явного указания.

Если задача требует изменения базы данных — сначала объясни, какая таблица и какие поля нужны.